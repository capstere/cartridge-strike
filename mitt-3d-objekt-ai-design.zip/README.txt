CARTRIDGE STRIKE CHARACTER STUDIO 6.0 / BLENDER + SPEL HANDOFF

SPEL_SOURCE.glb and PREVIEW.glb contain identical visible design prototypes.
For characters, read BLENDER_SPEL_GUIDE.md and SPEL_BRIDGE.json before import.
BASE_RIG.glb is the unmodified original animated game skeleton.
PROJECT.json stores editable controls and assets; AI_INSTRUCTIONS.md lists finishing requirements.
STATIC_PROTOTYPE.glb is a STATIC mesh of authored parts, not an animation-ready costume.
This handoff is NOT approved as FPS/game-ready or guaranteed SPEL Procreate-compatible.
All changes are local; the game runtime was not modified.
