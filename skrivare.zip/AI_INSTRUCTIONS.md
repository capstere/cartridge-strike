# CARTRIDGE STRIKE / 3D DESIGN HANDOFF

Project: Mitt 3D-objekt
Task: Create a reusable 3D prop

## Source and interpretation
The project contains a precisely positioned 3D primitive prototype and JSON. The object is NOT an animated game character.
The 4-angle reference PNG and annotations are creative direction, not exact topology.
PREVIEW.glb is the complete visible design prototype with its existing skeleton and animation clips. Preserve its visible appearance. New hair and rigid accessories require animation/intersection review; it is NOT a verified game-ready asset.
Use MANIFEST.json to map packaged references to their original names and hashes. Do not infer missing files.
PROJECT.json is the canonical editable specification; ANIMATION_CONTRACT.json is the compatibility checklist.

## Appearance
face: [unchanged / unspecified]
clothes: [unchanged / unspecified]
shoes: [unchanged / unspecified]
gear: [unchanged / unspecified]
general: [unchanged / unspecified]

## Modelled 3D components (coordinates in original unscaled model space, meters)
- ricoh_printer.glb (glb), anchor=root, pos=[0, 0.4, 0], rotation degrees=[0, 0, 0], dimensions m=[0.25, 0.25, 0.25], color=#56abc5, visible=true, note=none

## Character animation and FPS integration
Create a reusable optimized prop GLB with sensible origin/pivot, dimensions and collision suggestion.
Character animation requirements apply only if the prop is later attached to a character.

## Delivery acceptance
1. Preserve the authored dimensions, shape placement, colors and intended object pivot
2. Replace rough primitives with an efficient finished mesh if requested
3. Provide a collision suggestion for the target game environment
4. Optimize polygon count, draw calls, memory and mobile/WebGL performance
5. Avoid altering any existing game runtime or publishing user-supplied models without review
Provide final game-ready .glb, 4 orthographic views, a change log, and an integration note describing any rig/material differences.
The generated STATIC_PROTOTYPE.glb is a static shape concept; it is NOT the final rigged character and is not animation-complete.
Reference files are inspiration; use only what the user has rights to include.